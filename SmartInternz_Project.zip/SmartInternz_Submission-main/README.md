# SmartInternz_Submission
-------------------------------------------------------------------------------------------------
Video Demonstration Link
https://tinyurl.com/AbsenceEase
-------------------------------------------------------------------------------------------------
# FLOW CHART
<img width="495" alt="image" src="https://github.com/drzyadav/SmartInternz_Submission/assets/118712121/62b929c6-cfa8-4aac-bbcf-59bb6dc49c5b">

# SCREENSHOTS
<img width="295" alt="image" src="https://github.com/drzyadav/SmartInternz_Submission/assets/118712121/c4e7faf3-4744-4e63-8a09-a092e94a47de">
<img width="295" alt="image" src="https://github.com/drzyadav/SmartInternz_Submission/assets/118712121/1e2bea35-df6a-4a2d-8af8-ac0a2d8def66">
<img width="295" alt="image" src="https://github.com/drzyadav/SmartInternz_Submission/assets/118712121/f14b2544-d466-44cb-9e5c-a38aa725c8e5">
<img width="295" alt="image" src="https://github.com/drzyadav/SmartInternz_Submission/assets/118712121/9e5bbcc6-0236-46be-8710-f3ba675cd92b">
